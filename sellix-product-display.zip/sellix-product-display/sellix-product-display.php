<?php
/*
Plugin Name: Sellix Product Display
Description: Fetches and displays Sellix.io products for sale.
Version: 1.0
Author: <a href="https://discord.gg/MKnNmVNnPY">Cloudrack Development</a>
*/

// Include the admin settings file
include_once('settings-page.php');

// Include the Parsedown library
include_once('Parsedown.php');

// Register shortcode to display Sellix products
add_shortcode('sellix_products', 'sellix_display_products');

function sellix_display_products($atts) {
    // Fetch API URL and API key from database
    $api_url = get_option('sellix_api_url');
    $api_key = get_option('sellix_api_key');

    // Check if API URL is empty
    if (empty($api_url)) {
        return '<p>Error: API URL is not configured.</p>';
    }

    // Check if API key is empty
    if (empty($api_key)) {
        return '<p>Error: API Key is not configured.</p>';
    }

    // Fetch products from Sellix API
    $products = fetch_sellix_products($api_url, $api_key);

    // Check if there was an error fetching products
    if (is_wp_error($products)) {
        return '<p>Error fetching products: ' . $products->get_error_message() . '</p>';
    }

    // Display products
    $output = '<div class="sellix-products">';
    foreach ($products as $product) {
        $output .= '<div class="sellix-product">';
        $output .= '<h3 class="sellix-product-title">' . esc_html($product['title']) . '</h3>';
        $output .= '<p class="sellix-product-price"><strong>Price:</strong> $' . esc_html($product['price']) . ' ' . esc_html($product['currency']) . '</p>';

        // Convert Markdown content to HTML
        $parsedown = new Parsedown();
        $description_html = $parsedown->text($product['description']);

        // Display description in a non-editable text box
        // $output .= '<textarea class="sellix-product-description" readonly>' . esc_html($description_html) . '</textarea>';

        $output .= '<button class="sellix-product-button" data-sellix-product="' . esc_attr($product['uniqid']) . '">Learn More or Buy Now</button>';
        $output .= '</div>';
    }
    $output .= '</div>';

    // Enqueue Sellix JavaScript
    wp_enqueue_script('sellix-embed-js', 'https://cdn.sellix.io/static/js/embed.js', array(), null, true);

    // Enqueue styles
    wp_enqueue_style('sellix-embed-css', 'https://cdn.sellix.io/static/css/embed.css');
    wp_enqueue_style('sellix-product-display-style', plugins_url('sellix-product-display/style.css'));

    return $output;
}

// Function to fetch products from Sellix API (Replace this with your actual API fetching logic)
function fetch_sellix_products($api_url, $api_key) {
    // Check if API URL is empty
    if (empty($api_url)) {
        return new WP_Error('api_url_error', 'API URL is not configured.');
    }

    // Check if API key is empty
    if (empty($api_key)) {
        return new WP_Error('api_key_error', 'API Key is not configured.');
    }

    // Perform API request and fetch products
    // Replace this with your actual API request logic
    // Example:
    $response = wp_remote_get($api_url, array(
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($api_key . ':'),
        ),
    ));
    if (!is_wp_error($response) && $response['response']['code'] == 200) {
        $products = json_decode($response['body'], true);
        return $products;
    } else {
        return new WP_Error('api_error', 'Error fetching products.');
    }
}

// Activation hook
register_activation_hook(__FILE__, 'sellix_plugin_activate');

function sellix_plugin_activate() {
    // Create database table on plugin activation
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $sql = "CREATE TABLE wp_sellix_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        api_url VARCHAR(255) NOT NULL,
        api_key VARCHAR(255) NOT NULL
    ) $charset_collate;";
    dbDelta($sql);

    }

// Deactivation hook
register_deactivation_hook(__FILE__, 'sellix_plugin_deactivate');

function sellix_plugin_deactivate() {
    // Remove database table on plugin deactivation
    global $wpdb;
    $wpdb->query("DROP TABLE IF EXISTS wp_sellix_settings");
}
