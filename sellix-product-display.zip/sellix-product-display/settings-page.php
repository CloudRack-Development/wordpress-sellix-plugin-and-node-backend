<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add settings menu item
add_action('admin_menu', 'sellix_add_admin_menu');

function sellix_add_admin_menu() {
    add_options_page('Sellix Product Display', 'Sellix Product Display', 'manage_options', 'sellix-product-display', 'sellix_options_page');
}

// Register settings
add_action('admin_init', 'sellix_settings_init');

function sellix_settings_init() {
    register_setting('sellix_options_group', 'sellix_api_url');
    register_setting('sellix_options_group', 'sellix_api_key');

    add_settings_section(
        'sellix_settings_section',
        __('Sellix API Settings', 'sellix'),
        'sellix_settings_section_callback',
        'sellix-product-display'
    );

    add_settings_field(
        'sellix_api_url',
        __('API URL', 'sellix'),
        'sellix_api_url_render',
        'sellix-product-display',
        'sellix_settings_section'
    );

    add_settings_field(
        'sellix_api_key',
        __('API Key', 'sellix'),
        'sellix_api_key_render',
        'sellix-product-display',
        'sellix_settings_section'
    );
}

function sellix_api_url_render() {
    $api_url = get_option('sellix_api_url');
    ?>
    <input type="text" name="sellix_api_url" value="<?php echo esc_attr($api_url); ?>" />
    <?php
}

function sellix_api_key_render() {
    $api_key = get_option('sellix_api_key');
    ?>
    <input type="text" name="sellix_api_key" value="<?php echo esc_attr($api_key); ?>" />
    <?php
}

function sellix_settings_section_callback() {
    echo __('Enter your Sellix API details below.', 'sellix');
}

function sellix_options_page() {
    ?>
    <div class="wrap">
        <h1>Sellix Product Display</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('sellix_options_group');
            do_settings_sections('sellix-product-display');
            submit_button('Save Settings');
            ?>
        </form>
    </div>
    <?php
}

// Hook into admin_notices to display custom notification message when settings are saved
add_action('admin_notices', 'sellix_settings_saved_notification');

function sellix_settings_saved_notification() {
    if (isset($_GET['settings-updated'])) {
        $updated = $_GET['settings-updated'];
        if ($updated) {
            echo '<div class="notice notice-success is-dismissible"><p>';
            echo 'Settings saved successfully.';
            echo '</p></div>';
        }
    }
}
